﻿using CoffeeStation.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeStation
{
    public partial class Admin : Form
    {
        private readonly string WelcomeMessage;
        private readonly CoffeeEntities _context;
        public Admin(string message)
        {
            InitializeComponent();
            WelcomeMessage = message;
            _context = new CoffeeEntities();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = WelcomeMessage;
            dtgEmployeer.DataSource = _context.Users.Select(u => new
            {
                Fullname = u.Firstname + " " + u.Lastname,
                u.Email,
                u.Role.Name
            }).ToList(); 
        }

        private void employeerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employeer employeer = new Employeer();
            employeer.ShowDialog();
        }
    }
}
