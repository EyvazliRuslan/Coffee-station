﻿using CoffeeStation.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CoffeeStation.Utilities.Extension;

namespace CoffeeStation
{
    public partial class Employeer : Form
    {
        private readonly CoffeeEntities _context;
        public Employeer()
        {
            InitializeComponent();
            _context = new CoffeeEntities();
        }

        private void Employeer_Load(object sender, EventArgs e)
        {
            FillDataGridEmployeer();
            ComboEmployeer();
        }
        private void FillDataGridEmployeer()
        {
            dtgEmployeer.DataSource = _context.Users.Select(u => new
            {
                FullName = u.Firstname + " " + u.Lastname,
                u.Email,
                u.Role.Name
           
            }).ToList() ;
        }
        private void ComboEmployeer()
        {
            cmbRole.Items.AddRange(_context.Roles.ToArray());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string FirstName = txtFirstName.Text;
            string LastName = txtLastName.Text;
            string Email = txtEmail.Text;
            string Password = txtPassword.Text;
            //string Ruslan = cmbRole.Text;
            Role role = cmbRole.SelectedItem as Role;
            User user = new User()
            {
                Firstname = FirstName,
                Lastname = LastName,
                Email = Email,
                Password = GetHash(Password),
                RoleId = role.Id,
                CheckVerifiedPassword = false
                //RoleId = _context.Roles.First(r => r.Name == Ruslan).Id


            };
            _context.Users.Add(user);
            _context.SaveChanges();
            FillDataGridEmployeer();
            ShowMessage("User add successfully", "success");

        }
    }
}
