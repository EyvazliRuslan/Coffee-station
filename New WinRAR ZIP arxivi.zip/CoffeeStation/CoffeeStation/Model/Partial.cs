﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeStation.Model
{
    public partial class Role
    {
        public override string ToString()
        {
            return Name;
        }
    }
}
