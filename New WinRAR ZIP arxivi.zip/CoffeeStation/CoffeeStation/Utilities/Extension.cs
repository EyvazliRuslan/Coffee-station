﻿using CoffeeStation.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeStation.Utilities
{
    public class Extension
    {
        public static bool CheckAllField( string[]  UserInfo , string Empty )
        {
            foreach (string Field in UserInfo)
            {
                if (Field == Empty)
                {
                    return true;
                }
            }
            return false;
        }
        public static  bool CheckHash(string UserPassword, string TextboxPassword)
        {
            return UserPassword == GetHash(TextboxPassword);
        }
        public static string GetHash(string Password)
        {
            byte[] GetByte = new ASCIIEncoding().GetBytes(Password);
            byte[] GetHashedByte = new SHA256Managed().ComputeHash(GetByte);
                return new ASCIIEncoding().GetString(GetHashedByte);
        }
        public static void ShowMessage( string content, string title)
        {
            MessageBox.Show(content,title , MessageBoxButtons.OK, title.ToLower() == "error" ? MessageBoxIcon.Error : MessageBoxIcon.Information);
        }
    }
}
