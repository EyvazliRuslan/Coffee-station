﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoffeeStation.Model;
using static CoffeeStation.Utilities.Extension;

namespace CoffeeStation
{
    public partial class ChangePassword : Form
    {
        private readonly CoffeeEntities _context;
        private readonly User _LoginUser;
        public ChangePassword(User user)
        {
            InitializeComponent();
            _context = new CoffeeEntities();
            _LoginUser = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (CheckAllField(new string[] { txtCurrentPassword.Text,txtPassword.Text,txtRepeatPassword.Text}, String.Empty))
            {
                ShowMessage("Please Fill all fields", "Error");
                return;
            }
            if (GetHash(txtCurrentPassword.Text) != _LoginUser.Password)
            {
                ShowMessage("Current Password is wrong", "Error");
                return;
            }
            if (txtPassword.Text !=txtRepeatPassword.Text)
            {
                ShowMessage("Your new password is not match Repeat password", "Error");
                return;
            }
            this.Visible = false;
            User user = _context.Users.Where(m => m.Password == _LoginUser.Password).First();
            user.Password = GetHash(txtPassword.Text);
            user.CheckVerifiedPassword = true;
            _context.SaveChanges();
            ShowMessage($"Password changed successfully {_LoginUser.CheckVerifiedPassword}","Success");
            new Form1().ShowDialog();
            this.Close();
        }
    }
}
