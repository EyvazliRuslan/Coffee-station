﻿using CoffeeStation.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CoffeeStation.Utilities.Extension;

namespace CoffeeStation
{
    public partial class Form1 : Form
    {
        private readonly CoffeeEntities _context;
        public Form1()
        {
            InitializeComponent();
            _context = new CoffeeEntities();
        }


        private void CheckRemember()
        {
            if (CheckRememberMe.Checked)
            {
                Properties.Settings.Default.Email = txtUsername.Text;
                Properties.Settings.Default.Password = txtPassword.Text;
                Properties.Settings.Default.DefaultChecked = true;
                Properties.Settings.Default.Save();
            }
            else
            {
                Properties.Settings.Default.Email = String.Empty;
                Properties.Settings.Default.Password = String.Empty;
                Properties.Settings.Default.DefaultChecked = false;
                Properties.Settings.Default.Save();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.DefaultChecked)
            {
                txtUsername.Text = Properties.Settings.Default.Email;
                txtPassword.Text = Properties.Settings.Default.Password;
                CheckRememberMe.Checked = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] UserInfo = new string[] { txtUsername.Text, txtPassword.Text };
            if ( CheckAllField( Empty: String.Empty, UserInfo: UserInfo))
            {
                ShowMessage( "Please fill all field","Error");
                return;
            }
             User user = _context.Users.FirstOrDefault(u=>u.Email.ToLower() == txtUsername.Text.ToLower());
            if (user!= null)
            {
                if (CheckHash(user.Password,txtPassword.Text))
                {
                    this.Visible = false;
                    CheckRemember();
                    switch (user.RoleId)
                    {
                        case 1: new Admin( string.Concat(user.Firstname , " ",user.Lastname)).ShowDialog();
                            break;
                        case 2:
                            if (!user.CheckVerifiedPassword)
                            {
                                new ChangePassword(user).ShowDialog();
                            }
                            else
                            {
                                new Cashier(user).ShowDialog();
                            }
                            break;
                        default:
                            break;
                    }
                    this.Close();
                }
                else
                {
                    ShowMessage( "Invalid Username or Password","Error");
                }
            }
            else
            {
                ShowMessage( "Invalid Username or Password","Error");
            }
            
        }
    }
}
